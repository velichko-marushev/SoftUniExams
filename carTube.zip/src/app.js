import { page, render } from './lib.js';
import { getUserData } from './util.js';
import { logout } from './api/api.js';
import { homePage } from './views/home.js';
import { loginPage } from './views/login.js';
import { registerPage } from './views/register.js';
import { catalogPage } from './views/catalog.js';
import { createPage } from './views/create.js';
import { detailsPage } from './views/details.js';
import { editPage } from './views/edit.js';
import { myCarsPage } from './views/myCars.js';


const main = document.getElementById('site-content');
document.getElementById('logoutBtn').addEventListener('click',userLogout);
page(decorateContext)
page('/',homePage);
page('/login',loginPage);
page('/register',registerPage);
page('/catalog',catalogPage);
page('/create',createPage);
page('/details/:id',detailsPage);
page('/edit/:id',editPage);
page('/myCars',myCarsPage);


updateUserNav()
page.start()

function decorateContext(ctx,next){
    ctx.render = (content) => render(content, main)
    ctx.updateUserNav = updateUserNav
    next()
}   


function userLogout() {
    
    logout()
    updateUserNav()
    page.redirect('/')
}

function updateUserNav() {
    const userData = getUserData()
    const guest = document.getElementById('guest')
    const user = document.getElementById('profile')
    const userWelcome = document.getElementById('welcome')

  if (userData) {
      user.style.display = 'block'
      guest.style.display = 'none'
      userWelcome.textContent = `Welcome ${userData.username}`
  }else{
    user.style.display = 'none'
    guest.style.display = 'block'
  }



}

