import { editGame, getGameById } from "../api/data.js";
import { html, render, page } from "../lib.js";


const editTemaplate = (game,onSubmit) => html`
<section id="edit-page" class="auth">
    <form @submit=${onSubmit} id="edit">
        <div class="container">

            <h1>Edit Game</h1>
            <label for="leg-title">Legendary title:</label>
            <input type="text" id="title" name="title" value="">

            <label for="category">Category:</label>
            <input type="text" id="category" name="category" value="">

            <label for="levels">MaxLevel:</label>
            <input type="number" id="maxLevel" name="maxLevel" min="1" value="">

            <label for="game-img">Image:</label>
            <input type="text" id="imageUrl" name="imageUrl" value="">

            <label for="summary">Summary:</label>
            <textarea name="summary" id="summary"></textarea>
            <input class="btn submit" type="submit" value="Edit Game">

        </div>
    </form>
</section>`

export async function editPage(ctx){
    const game = await getGameById(ctx.params.id);

    ctx.render(editTemaplate(game,onSubmit))

    async function onSubmit(event) {
        event.preventDefault();

        const formData = new FormData(event.target);
        const title = formData.get('title').trim();
        const category = formData.get('category').trim();
        const maxLevel = formData.get('maxLevel').trim();
        const imageUrl = formData.get('imageUrl').trim();
        const summary = formData.get('summary').trim();

        if (title == '' || category == '' || imageUrl == ''|| summary == ''|| maxLevel =="") {
            return alert('All fields are required')
        }
        await edityGame(ctx.params.id,{
            title,
            category,
            maxLevel,
            imageUrl,
            summary
        })
        ctx.page.redirect(`/details/${game._id}`)
    }
}