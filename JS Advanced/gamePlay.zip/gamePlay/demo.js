    

//         <!-- Main Content -->
//         <main id="main-content">
//         </main>

//         <!--Home Page-->
       

//         <!-- Login Page ( Only for Guest users ) -->
        

//         <!-- Register Page ( Only for Guest users ) -->
       

//         <!-- Create Page ( Only for logged-in users ) -->
        

//         <!-- Edit Page ( Only for the creator )-->
       

//         <!--Details Page-->
       

//         <!-- Catalogue -->
{/* <article class="create-comment">
<label>Add new comment:</label>
<form class="form">
    <textarea name="comment" placeholder="Comment......"></textarea>
    <input class="btn submit" type="submit" value="Add Comment">
</form>
</article> */}

// </html>