import { logout } from './api/api.js';
import { page, render } from './lib.js';
import { getUserData } from './util.js';
import { catalogPage } from './views/catalog.js';
import { createPage } from './views/create.js';
import { detailsPage } from './views/detailsWithBonus.js';
import { editPage } from './views/edit.js';
import { loginPage } from './views/login.js';
import { myBooksPage } from './views/myBooks.js';
import { registerPage } from './views/register.js';





const main = document.getElementById('site-content')
document.getElementById('logoutBtn').addEventListener('click', onLogout)

page(decoration)
page('/login',loginPage)
page('/register',registerPage)
page('/create',createPage)
page('/',catalogPage)
page('/details/:id',detailsPage)
page('/edit/:id',editPage)
page('/myBooks',myBooksPage)


updateUserNav()
page.start()


function decoration(ctx, next) {
    ctx.render = (content) => render(content, main)
    ctx.updateUserNav = updateUserNav
    next()
}

function onLogout(){
logout()
updateUserNav()
page.redirect('/')
}

function updateUserNav(){
    const userData = getUserData()
    if (userData) {
        document.getElementById('user').style.display = 'block'
        document.getElementById('guest').style.display = 'none'
        document.getElementById('welcome').textContent = `Welcome, ${userData.email}`
    }else{
        document.getElementById('user').style.display = 'none'
        document.getElementById('guest').style.display = 'block'
    }
}